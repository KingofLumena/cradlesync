import cradlesync

def test_protocol_run():
    cradlesync.initiate_inheritance("sample_bundle/child_first_cry.ndjson", "FLAMECERT-KING-LMN-77VA")
